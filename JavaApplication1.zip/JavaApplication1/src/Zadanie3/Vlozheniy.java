package Zadanie3;

import java.util.Scanner;

public class Vlozheniy {
    public static void main(String[] args){}
    int i = 0;
     public class Vlozheniy1{
           public void TextVLozh1() {       
            Scanner in = new Scanner(System.in);
            System.out.println("Введите число:");
            i = in.nextInt();
            System.out.print("текст вложенного класса и число: " + i);
            }  
    
     }
    public void start(){
    Vlozheniy1 vlozheniy = new Vlozheniy1();
    vlozheniy.TextVLozh1();
    System.out.print("Работа выполена " + i);
    }

    @Override
    public String toString() {
        return "Vlozheniy{" + "i=" + i + '}';
    }
     
}


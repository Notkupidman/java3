package Zadanie3;

import Zadanie1.JavaApplication3;

public class Vnutrenniy{

         public static class JavaA5 extends JavaApplication3{
            public JavaA5(String lastname, String name, String middlename, int number) {
            this.name = name;
            this.middlename = middlename;
            chislaName();
            chislaLastName();
            pozdravlenie3();
            }
        }
         
    }
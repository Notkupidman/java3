package Zadanie4;
import java.util.Arrays;
import java.util.Random;
 
public class TEST1 {
    public static void main(String[] args) {
        Random random = new Random();
        int lengthArray = random.nextInt(10); //рандомная длина масива до 10
        int[] a = new int[lengthArray];
        int count = 0;
        int max = 0;
        int min = 0;
        int sum = 0;
        int sum1 = 0;
        for (int i = 0; i < a.length; i++) { //заполняем массив случайными числами от -10 до 10
            a[i] = random.nextInt(11)-5;
        } 
        System.out.println("Массив: " + Arrays.toString(a));
        for (int i = 0; i < a.length; i++){ //ищем кол-во отрицательных элементов 
            if (a[i] < 0)count++;
                if (a[i] > max){
                    max = a[i];
                } 
                if (a[i] < min){
                    min = a[i];
                }
            sum = count + max;
            sum1 = count + min;
        }
        System.out.println("ОТВЕТ: Наш массив имеет " + count + " отрицательных числа(-ел);");
        System.out.println("Максимальное число: " + max);
        System.out.println("Минимальное число: " + min);
        System.out.println("Сумма максимального числа: " + sum);
        System.out.println("Сумма минимального числа: " + sum1);
    }
}

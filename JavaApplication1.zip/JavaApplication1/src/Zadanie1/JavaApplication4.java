
package Zadanie1;
import java.util.Scanner;

public class JavaApplication4 extends JavaApplication3 {
    public String name;
    public String middlename;
    public int number;
    
    public void chislaNomer(){
        Scanner in = new Scanner(System.in);
        System.out.println("Введите число:");
        number = in.nextInt();
        }
    
    public JavaApplication4(String name, String middlename) {
        this.name = name;
        this.middlename = middlename;
    }
     public JavaApplication4(String lastname, String name, String middlename, int number) {
        this.name = name;
        this.middlename = middlename;
        chislaName();
        chislaLastName();
        chislaNomer();
        pozdravlenie3();
    }
     @Override
        public void pozdravlenie3(){ 
        System.out.println("Ого, ты внёс номер " + "'" + name + "'" + " и, Фамилию " + "'" + middlename + "'" + " в телефонную книжку");
        }
        
    @Override
    public String toString() {
        return "[" + "вакцинирован= " + vaccinated + "]" + " " + lastname + " " + name+ " " + middlename/* + " - " + number*/;
    }
       
    }

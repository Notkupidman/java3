package Zadanie1;

import java.io.Serializable;
import java.util.Scanner;

public class JavaApplication3 implements JavaInterface1, Serializable{

    public String lastname;
    public String name;
    public String middlename;
    public int number;
    public boolean vaccinated;
    
    public void chislaName(){
        Scanner in = new Scanner(System.in, "Cp1251");
        System.out.println("Введите имя:");
        name = in.nextLine();
    }
    public void chislaLastName(){
        Scanner in = new Scanner(System.in, "Cp1251");
        System.out.println("Введите Фамилию:");
        lastname = in.nextLine();
    }
    public void pozdravlenie3(){
        System.out.println("Ого, ты внёс номер " + "'" + number + "'" + " и, Фамилию " + "'" + name + "'" + " в телефонную книжку");
    }
    public void pozdravlenie4(){
        System.out.println("Ого, ты внёс номер " + "'" + number + "'" + " и, Фамилию " + "'" + name + "'" + " в телефонную книжку");
    }
    public JavaApplication3() {
        lastname = " ";
        name = " ";
        number = 0;
        vaccinated = true;
    }
    public JavaApplication3(String lastname, String middlename, int number) {
        this.lastname = lastname;
        this.number = number;
        this.middlename = middlename;
        chislaName();
        outmassage();
    }
    public JavaApplication3(String lastname, String name, String middlename, int number) {
        this.name = name;
        this.middlename = middlename;
        chislaName();
        chislaLastName();
    }
    public JavaApplication3(boolean vaccinated, String lastname, String name, String middlename, int number) {
        this.lastname = lastname;
        this.name = name;
        this.middlename = middlename;
        this.number = number;
        this.vaccinated = vaccinated;
    }
    public JavaApplication3(boolean vaccinated, String lastname, String name, int number) {
        this.lastname = lastname;
        this.name = name;
        this.number = number;
        this.vaccinated = vaccinated;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }
    
    @Override
    public String toString(){
        return "[" + "вакцинирован= " + vaccinated + "]" + " " + lastname + " " + name+ " " + middlename + " - " + number;
    }

   
    
    
    @Override
    public void outmassage() {
        pozdravlenie3();
    }
    
}

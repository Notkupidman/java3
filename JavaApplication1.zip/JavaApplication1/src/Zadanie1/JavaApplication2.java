package Zadanie1;

import java.util.Scanner;


public class JavaApplication2 {

    private String lastname;
    private String name;
    private String middlename;
    private int number;
    private boolean vaccinated;
    
    public void chislaNomer(){
        Scanner in = new Scanner(System.in);
        System.out.println("Введите число:");
        number = in.nextInt();
    }
    private void pozdravlenie(){
        System.out.println("Ого, ты внёс номер " + "'" + number + "'" + " в телефонную книжку");
    }
    
    public JavaApplication2() {
        lastname = " ";
        name = " ";
        middlename = " ";
        number = 0;
        vaccinated = true;
    }


    
    public JavaApplication2(String lastname, String name, String middlename, boolean vaccinated) {
        this.lastname = lastname;
        this.name = name;
        this.middlename = middlename;
        this.vaccinated = vaccinated;
        chislaNomer();
        pozdravlenie();
    }
    
    public JavaApplication2(String lastname, String name, int number) {
        this.lastname = lastname;
        this.name = name;
        this.number = number;
    }
    public JavaApplication2(String lastname, String name, String middlename, int number) {
        this.lastname = lastname;
        this.name = name;
        this.middlename = middlename;
        this.number = number;
        
    }
    public JavaApplication2(boolean vaccinated, String lastname, String name, String middlename, int number) {
        this.lastname = lastname;
        this.name = name;
        this.middlename = middlename;
        this.number = number;
        this.vaccinated = vaccinated;
    }
    public JavaApplication2(boolean vaccinated, String lastname, String name, int number) {
        this.lastname = lastname;
        this.name = name + " - super";
        this.number = number;
        this.vaccinated = vaccinated;
    }
    
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middlename) {
        this.middlename = middlename;
    }

     public void getNumber() {
        this.number = number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public boolean isVaccinated() {
        return vaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        this.vaccinated = vaccinated;
    }
    
   
    @Override
    public String toString(){
        return "[" + "вакцинирован= " + vaccinated + "]" + " " + lastname + " " + name+ " " + middlename + " - " + number;
    }

    
}

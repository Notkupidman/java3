
package Zadanie1;

public interface JavaInterface1 {
    
    String MASSAGE = "сообщение";
  
    void outmassage();
}

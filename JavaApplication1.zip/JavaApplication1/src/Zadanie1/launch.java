
package Zadanie1;

public class launch {
    public static void main(String[] args) {
       JavaApplication1 dima = new JavaApplication1(true, "Петров", "Дима", 541535);
       System.out.println(dima);
       
       JavaApplication2 dima2 = new JavaApplication2(true, "Петров", "Дима", 541535);
       System.out.println(dima2);
       
       JavaApplication2 dima3 = new JavaApplication2("Петров", "Дима", "Сидоров", true);
       System.out.println(dima3);
       
        JavaApplication3 dima4 = new JavaApplication3("Петров", "Дима", "Сидоров", 541535);
        System.out.println(dima4);
        
        JavaApplication4 dima5 = new JavaApplication4("Петров", "Дима", "Сидоров", 541535);
        System.out.println(dima5);
        
        Zadanie3.Vnutrenniy.JavaA5 dima6 = new Zadanie3.Vnutrenniy.JavaA5("Петров", "Дима", "Сидоров", 541535);
        System.out.println(dima6);
    }      
}

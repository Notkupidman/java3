package Zadanie2;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;
import java.util.List;
import java.util.Set;
import java.util.Map;


  public class MathAnswer {
    public static void main(String[] args) {
       List<Integer> list = new ArrayList<>();
       Set<Integer> set = new HashSet<>();
       Map<Integer, String> map = new HashMap();
        Scanner INPUT = new Scanner(System.in, "Cp1251");
        int num;
        int num1;
        System.out.println("Введите количество элементов:");
	num1 = Integer.parseInt(INPUT.nextLine());
        for(int i=0; i<num1; i++) {
            System.out.println("Введите элементы массива:"); 
            num = INPUT.nextInt();
            list.add(num);
            set.add(num);
            map.put(num,"");
                System.out.println("массив List: " + list);
                System.out.println("массив Set: " + set);
                System.out.println("массив Map: " + map);
        }
            list.remove(0);    
            System.out.println("введите элемент для удаления в SET: ");
            set.remove(INPUT.nextInt());
            System.out.println("введите элемент для удаления в MAP: ");
            map.remove(INPUT.nextInt());  
            System.out.println("введите элементы для добавления: ");
            list.add(INPUT.nextInt());
            set.add(INPUT.nextInt());
            map.put(INPUT.nextInt()," "); 
                System.out.println("массив List: " + list);
                System.out.println("массив Set: " + set);
                System.out.println("массив Map: " + map);
                
                
    }
    
  }

package Zadanie7;

import Zadanie1.JavaApplication3;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ReadObject {
    public static void main(String[] args){
        try {
            FileInputStream fis = new FileInputStream("people.bin");
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            Serial person1 = (Serial) ois.readObject();
            Serial person2 = (Serial) ois.readObject();
            JavaApplication3 person3 = (JavaApplication3) ois.readObject();
            JavaApplication3 person4 = (JavaApplication3) ois.readObject();
            
            System.out.println(person1);
            System.out.println(person2);
            System.out.println(person3);
            System.out.println(person4);
            
            ois.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ReadObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ReadObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ReadObject.class.getName()).log(Level.SEVERE, null, ex);
        }
     
    }    
}

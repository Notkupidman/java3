
package Zadanie7;

import Zadanie1.JavaApplication3;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WriteObject {
    public static void main(String[] args){
        JavaApplication3 person3 = new JavaApplication3("lastname", "name", 4);
        JavaApplication3 person4 = new JavaApplication3("lastname4", "name4", 4);
        
        Serial person1 = new Serial(1, "Odin");
        Serial person2 = new Serial(2, "Dva");
        
        try {
            FileOutputStream fos = new FileOutputStream("people.bin");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(person1);
            oos.writeObject(person2);
            oos.writeObject(person3);
            oos.writeObject(person4);
            
            oos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(WriteObject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WriteObject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
            
}
